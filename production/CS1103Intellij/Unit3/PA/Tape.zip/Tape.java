package Unit3.PA;

public class Tape {
	
	private Cell currentCell;
	public Tape() {
		Cell newCell = new Cell();
		newCell.content = ' ';
		newCell.prev = null;
		newCell.next = null;
		currentCell = newCell;
	}
	
	public Cell getCurrentCell() {
		return currentCell;
	}
	
	public char getContent() {
		return currentCell.content;
	}

	public void setContent(char ch) {
		currentCell.content = ch;
	}
	
	public void moveLeft() {
		if (currentCell.prev == null) {
			Cell newCell = new Cell();
			newCell.content = ' ';
			newCell.prev = null;
			newCell.next = currentCell;
			currentCell.prev = newCell;
		}
		currentCell = currentCell.prev;
	}
	
	public void moveRight() {
		if (currentCell.next == null) {
			Cell newCell = new Cell();
			newCell.content = ' ';
			newCell.next = null;
			newCell.prev = currentCell;
			currentCell.next = newCell;
		}
		currentCell = currentCell.next;
	}
	
	public String getTapeContents() {
		Cell pointer = currentCell;
		while (pointer.prev != null)
			pointer = pointer.prev;
		String strContent = "";
		while (pointer != null) {
			strContent += pointer.content;
			pointer = pointer.next;
		}
		strContent = strContent.trim();
		return strContent;
	}
}